package com.example.jerwin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
